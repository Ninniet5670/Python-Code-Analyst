def func_test(t):
    print  (t)