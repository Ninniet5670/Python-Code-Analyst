import math
def func_test(t):
    print  (t)

import os